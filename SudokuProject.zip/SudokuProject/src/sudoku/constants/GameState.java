package sudoku.constants;
//enum represents different states that the game can be in
public enum GameState {
    COMPLETE,
    ACTIVE,
    NEW,
}