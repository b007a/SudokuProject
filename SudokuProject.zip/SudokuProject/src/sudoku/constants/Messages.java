package sudoku.constants;

public class Messages {
    public static final String GAME_COMPLETE = "Congratulations, you won the game. Do you want to play again?";
    public static final String ERROR = "An error has occurred.";
}
